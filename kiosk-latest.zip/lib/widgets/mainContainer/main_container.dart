import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kiosk/controllers/cart.dart';
import 'package:kiosk/main.dart';
import 'package:kiosk/screens/index.dart';
import 'package:kiosk/ui/index.dart';
import 'package:kiosk/utils/index.dart';
import 'package:kiosk/widgets/index.dart';
import 'package:sizer/sizer.dart';

// Widget mainContainer({
//   required BuildContext context,
//   required Widget child,
//   required bool showLeftUpperIcon,
//   required bool showRightBottomIcon,
//   required bool showLeftBottomIcon,
//   required bool showText,
//   String text = "",
// }) {
//  }
class MainContainer extends StatefulWidget {
  final Widget child;
  final bool showLeftUpperIcon;
  final bool showRightBottomIcon;
  final bool showLeftBottomIcon;
  final bool showText;
  String text = "";
  MainContainer({
    super.key,
    required this.child,
    required this.showLeftUpperIcon,
    required this.showRightBottomIcon,
    required this.showLeftBottomIcon,
    required this.showText,
    this.text = "",
  });

  @override
  State<MainContainer> createState() => _MainContainerState();
}

class _MainContainerState extends State<MainContainer> {
  // late CameraController _cameraController;
  // late Future<void> _initializeFutureController;
  // int selectedCamera = 0;
  // bool loading = true;
  @override
  void initState() {
    super.initState();
    // initializeCamera(selectedCamera);
  }

  @override
  void dispose() {
    // _cameraController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cartController = Get.find<Cart>();
    return Container(
      padding: EdgeInsets.fromLTRB(5.w, 0, 5, 0),
      decoration: BoxDecoration(
        color: Theme.of(context).primaryColor,
      ),
      child: Stack(
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(5, 15.h, 0, 5.h),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                        width: 15.w,
                        child: widget.showText
                            ? widget.text.split(" ").length == 1
                                ? Text(
                                    widget.text,
                                    style: (widget.text == menu ||
                                            widget.text == meals)
                                        ? Theme.of(context).textTheme.headline2
                                        : Theme.of(context)
                                            .textTheme
                                            .headline2!
                                            .copyWith(color: kErrorColor),
                                  )
                                : Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                        Text(
                                          widget.text.split(" ")[0],
                                          style: Theme.of(context)
                                              .textTheme
                                              .headline2!
                                              .copyWith(
                                                color: kErrorColor,
                                              ),
                                        ),
                                        Text(
                                          widget.text.split(" ")[1],
                                          style: Theme.of(context)
                                              .textTheme
                                              .headline2!
                                              .copyWith(
                                                  color: kErrorColor,
                                                  fontSize:
                                                      (heading2Size - 2).sp,
                                                  height: 1),
                                        ),
                                      ])
                            : const Text("")),
                    SizedBox(
                      width: 60.w,
                      height: 20.h,
                      child: !loading
                          ? FutureBuilder(
                              future: initializeFutureController,
                              builder: (context, snapshot) {
                                if (cameraController.value.isInitialized) {
                                  // If the Future is complete, display the preview.
                                  // return AspectRatio(
                                  //     aspectRatio:
                                  //         cameraController.value.aspectRatio,
                                  //     child: CameraPreview(cameraController));
                                  return Stack(fit: StackFit.expand, children: [
                                    CameraPreview(cameraController),

                                    // Positioned(
                                    //   bottom: 0,
                                    //   right: 0,
                                    //   child: GestureDetector(
                                    //     onTap: () {
                                    //       final lensDirection = cameraController
                                    //           .description.lensDirection;
                                    //       CameraDescription newDescription;
                                    //       if (lensDirection ==
                                    //           CameraLensDirection.front) {
                                    //         newDescription = cameras.firstWhere(
                                    //             (description) =>
                                    //                 description.lensDirection ==
                                    //                 CameraLensDirection.back);
                                    //       } else {
                                    //         newDescription = cameras.firstWhere(
                                    //             (description) =>
                                    //                 description.lensDirection ==
                                    //                 CameraLensDirection.front);
                                    //       }
                                    //       initializeCamera(
                                    //           selectedCamera, newDescription);
                                    //       setState(() {});
                                    //     },
                                    //     child: const Icon(
                                    //       Icons.flip_camera_ios_outlined,
                                    //       color: kPrimaryColor,
                                    //     ),
                                    //   ),
                                    // ),
                                  ]);
                                } else {
                                  // Otherwise, display a loading indicator.
                                  return const Center(
                                      child: CircularProgressIndicator());
                                }
                              },
                            )
                          : Image.asset(
                              recPic,
                            ),
                    ),
                    SizedBox(width: 15.w, child: const Text("")),
                  ],
                ),
                widget.child
              ],
            ),
          ),
          Positioned(
              left: 0,
              top: 0,
              child: widget.showLeftUpperIcon
                  ? Hero(
                      tag: "main", child: mainPicWidget(width: 15, height: 20))
                  : const Text("")),
          Positioned(
            right: 0,
            bottom: 0,
            child: widget.showRightBottomIcon
                ? GestureDetector(
                    onTap: () {
                      Get.to(() => const ViewCartScreen(),
                          transition: Transition.downToUp,
                          duration: const Duration(
                            milliseconds: transitionMilliseconds,
                          ));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        okHandWidget(width: 12, height: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: EdgeInsets.fromLTRB(5.w, 0, 0, 0),
                              child: Container(
                                width: 5.w,
                                height: 2.h,
                                decoration: BoxDecoration(
                                  color: Colors.transparent,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: kErrorColor,
                                    width: 1.0,
                                    style: BorderStyle.solid,
                                  ),
                                ),
                                child: Center(
                                  child: Obx(
                                    () => Text(
                                      cartController.cartItems.length
                                          .toString(),
                                      style: TextStyle(
                                        color: kErrorColor,
                                        fontSize: 8.sp,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            cartWidget(height: 7, width: 15),
                            Text(viewCart,
                                style: Theme.of(context).textTheme.bodyText1)
                          ],
                        )
                      ],
                    ),
                  )
                : const Text(""),
          ),
          Positioned(
            left: 0,
            bottom: 0,
            child: widget.showLeftBottomIcon
                ? GestureDetector(
                    onTap: () => {
                      if (widget.text != confirmation)
                        {Get.back()}
                      else
                        {
                          Get.offAll(() => const WelcomeScreen(),
                              transition: Transition.fadeIn,
                              duration: const Duration(
                                  milliseconds: transitionMilliseconds))
                        }
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        fiveHandWidget(),
                        kHorizontalNormalSpace(),
                        Text(back, style: Theme.of(context).textTheme.bodyText1)
                      ],
                    ),
                  )
                : const Text(""),
          ),
        ],
      ),
    );
  }

  // void initializeCamera(int cameraIndex) {
  //   _cameraController = CameraController(
  //     cameras[cameraIndex],
  //     ResolutionPreset.medium,
  //   );
  //   _initializeFutureController = _cameraController.initialize();
  //   setState(() {
  //     loading = false;
  //   });
  // }
}
