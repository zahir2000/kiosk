import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

Widget kHorizontalNormalSpace() => SizedBox(
      width: 5.w,
    );
Widget kVerticalSmallSpace() => SizedBox(
      height: 3.h,
    );
Widget kVerticalNormalSpace() => SizedBox(
      height: 5.h,
    );
Widget kVerticalMediumSpace() => SizedBox(
      height: 10.h,
    );
