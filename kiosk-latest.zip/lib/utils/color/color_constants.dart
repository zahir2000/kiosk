import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFFEFE8E8);
const kErrorColor = Color(0xFFFF5B4D);
const kTextColor = Color(0xFF000000);
