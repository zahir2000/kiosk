import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kiosk/controllers/cart.dart';
import 'package:kiosk/screens/index.dart';
import 'package:kiosk/ui/index.dart';
import 'package:sizer/sizer.dart';

import '../../utils/index.dart';
import '../../widgets/index.dart';

class ViewCartScreen extends StatefulWidget {
  const ViewCartScreen({super.key});

  @override
  State<ViewCartScreen> createState() => _ViewCartScreenState();
}

class _ViewCartScreenState extends State<ViewCartScreen> {
  final cartController = Get.find<Cart>();
  bool screenBouncing = true, hasOrder = false;
  void setScreenPhysics() {
    setState(() {
      screenBouncing = cartController.cartItems.length > 7;
      hasOrder = cartController.cartItems.isNotEmpty;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setScreenPhysics();
  }

  @override
  Widget build(BuildContext context) {
    return responsiveScreen(
      singleChildScroll: screenBouncing,
      showLeftBottomIcon: true,
      showRightBottomIcon: false,
      showLeftUpperIcon: true,
      showText: true,
      text: '$your $order',
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Container(
          padding: EdgeInsets.fromLTRB(0, hasOrder ? 10.h : 15.h, 0, 0),
          child: SizedBox(
            width: 80.w,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  children: cartController.cartItems.map((i) {
                    if (i.itemName != '$large $meal' &&
                        i.itemName != '$medium $meal') {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '${i.quantity} x ${i.itemName}',
                            style: Theme.of(context).textTheme.bodyText1,
                          ),
                          kVerticalNormalSpace(),
                        ],
                      );
                    } else {
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '${i.quantity} x ${i.itemCategory}',
                            style: Theme.of(context).textTheme.bodyText1,
                          ),
                          Text(
                            i.itemName!,
                            style: Theme.of(context).textTheme.bodyText1,
                          ),
                        ],
                      );
                    }
                  }).toList(),
                ),
                kVerticalSmallSpace(),
                hasOrder
                    ? myRow(
                        handName: "one",
                        text: '$proceed $to $payment',
                        context: context,
                        onTap: () => Get.to(
                          () => const PaymentScreen(),
                          transition: Transition.downToUp,
                          duration: const Duration(
                            milliseconds: transitionMilliseconds,
                          ),
                        ),
                        mainAxisAlignment: MainAxisAlignment.start,
                      )
                    : Text(
                        '$no $order $yet!',
                        style: Theme.of(context).textTheme.bodyText1,
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
